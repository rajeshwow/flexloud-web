import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { Client } from "../../shared/Utils/api-client";
import { withTenant } from "../../shared/Utils/utils";

export type LeadStatus =
  | "New"
  | "Converted"
  | "In Process"
  | "Recycled"
  | "Dead"
  | "Assigned"
  | string;

export type LeadEmailItem = {
  email: string;
  primary?: boolean;
  opt_out?: boolean;
  invalid?: boolean;
};

export type LeadItem = {
  id: string;
  lead_number?: string;
  lead_display_id?: string;
  address?: string;

  first_name?: string;
  last_name?: string;

  mobile?: string;
  office_phone?: string;

  organization_name?: string;
  contact_name?: string;

  status_id?: string;
  status_label?: string;
  priority_id?: string;
  priority_label?: string;
  source_id?: string;
  source_label?: string;

  next_followup?: string;
  next_followup_date?: string;

  assigned_to?: string;
  assigned_to_name?: string;

  designation?: string;

  address_line_1?: string;
  address_line_2?: string;
  city?: string;
  state?: string;
  country?: string;
  zip_code?: string;

  description?: string;
  remarks?: string;
  notes?: string;

  created_at?: string;
  updated_at?: string;
  created_by_name?: string;
  updated_by_name?: string;

  emails?: LeadEmailItem[];

  primary_address_street?: string;
  primary_address_area?: string;
  primary_address_postal_code?: string;
  primary_address_city?: string;
  primary_address_state?: string;
  primary_address_country?: string;
};

export type LeadsInsightItem = {
  key: string;
  label: string;
  percent: number;
  total: number;
};

export type FetchLeadsParams = {
  page?: number;
  limit?: number;
  search?: string;
  status?: string;
  assigned_to?: string;
};

export type CreateLeadPayload = {
  lead_number?: string;
  name: string;
  status?: string | null;
  organization_name?: string | null;
  office_phone?: string | null;
  email?: string | null;
  next_followup?: string | null;
  mobile?: string | null;
  company?: string | null;
  source?: string | null;
  description?: string | null;
};

type UpdateLeadPayload = {
  id: string;
  lead_number?: string;
  first_name?: string | null;
  last_name?: string | null;
  designation?: string | null;
  industry?: string | null;
  mobile?: string | null;
  office_phone?: string | null;
  organization_name?: string | null;
  emails?: LeadEmailItem[] | null;
  dealer_organization?: string | null;
  status?: string | null;
  product_category?: string | null;
  priority?: string | null;
  requirements?: string | null;
  next_followup?: string | null;
  followup?: string | null;
  followup_type?: string | null;
  lead_source?: string | null;
  add_description?: string | null;
  description?: string | null;
  referred_by?: string | null;
  assigned_to?: string | null;
  opportunity_name?: string | null;
  opportunity_amount?: number | null;
  expected_close_date?: string | null;
  sales_stage?: string | null;
  primary_address_street?: string | null;
  primary_address_area?: string | null;
  primary_address_postal_code?: string | null;
  primary_address_city?: string | null;
  primary_address_state?: string | null;
  primary_address_country?: string | null;
  alternate_address_street?: string | null;
  alternate_address_area?: string | null;
  alternate_address_postal_code?: string | null;
  alternate_address_city?: string | null;
  alternate_address_state?: string | null;
  alternate_address_country?: string | null;
};

type FetchLeadsResponse = {
  data: LeadItem[];
  total: number;
  page: number;
  limit: number;
  insights?: {
    status_breakdown: LeadsInsightItem[];
  };
};

type FetchLeadByIdResponse = {
  data: LeadItem;
};

type CreateLeadResponse = {
  message: string;
  data: LeadItem;
};

type UpdateLeadResponse = {
  message: string;
  data: LeadItem;
};

type DeleteLeadResponse = {
  message: string;
  id: string;
};

type LeadsState = {
  leads: LeadItem[];
  leadDetails: LeadItem | null;

  listLoading: boolean;
  listError: string | null;
  total: number;
  page: number;
  limit: number;
  insights?: {
    status_breakdown: LeadsInsightItem[];
  };

  detailsLoading: boolean;
  detailsError: string | null;

  createLoading: boolean;
  createError: string | null;
  createSuccess: boolean;

  updateLoading: boolean;
  updateError: string | null;
  updateSuccess: boolean;

  deleteLoading: boolean;
  deleteError: string | null;
  deleteSuccess: boolean;
};

const initialState: LeadsState = {
  leads: [],
  leadDetails: null,

  listLoading: false,
  listError: null,
  total: 0,
  page: 1,
  limit: 20,
  insights: undefined,

  detailsLoading: false,
  detailsError: null,

  createLoading: false,
  createError: null,
  createSuccess: false,

  updateLoading: false,
  updateError: null,
  updateSuccess: false,

  deleteLoading: false,
  deleteError: null,
  deleteSuccess: false,
};

export const fetchLeads = createAsyncThunk<
  FetchLeadsResponse,
  FetchLeadsParams | undefined,
  { rejectValue: string }
>("leads/fetchLeads", async (params, { rejectWithValue }) => {
  try {
    const response = await Client.get(withTenant("/leads"), {
      params: {
        page: params?.page ?? 1,
        limit: params?.limit ?? 20,
        search: params?.search || undefined,
        status: params?.status || undefined,
        assigned_to: params?.assigned_to || undefined,
      },
    });

    return {
      data: response?.data?.data || [],
      total: response?.data?.total || 0,
      page: response?.data?.page || params?.page || 1,
      limit: response?.data?.limit || params?.limit || 20,
      insights: response?.data?.insights || undefined,
    };
  } catch (error: any) {
    return rejectWithValue(
      error?.response?.data?.message || "Failed to fetch leads",
    );
  }
});

export const fetchLeadById = createAsyncThunk<
  FetchLeadByIdResponse,
  string,
  { rejectValue: string }
>("leads/fetchLeadById", async (id, { rejectWithValue }) => {
  try {
    const response = await Client.get(withTenant(`/leads/${id}`));

    return {
      data: response?.data?.data,
    };
  } catch (error: any) {
    return rejectWithValue(
      error?.response?.data?.message || "Failed to fetch lead details",
    );
  }
});

export const createLead = createAsyncThunk<
  CreateLeadResponse,
  CreateLeadPayload,
  { rejectValue: string }
>("leads/createLead", async (payload, { rejectWithValue }) => {
  try {
    const response = await Client.post(withTenant("/leads"), payload);

    return {
      message: response?.data?.message || "Lead created successfully",
      data: response?.data?.data,
    };
  } catch (error: any) {
    return rejectWithValue(
      error?.response?.data?.message || "Failed to create lead",
    );
  }
});

export const updateLead = createAsyncThunk<
  UpdateLeadResponse,
  UpdateLeadPayload,
  { rejectValue: string }
>("leads/updateLead", async (payload, { rejectWithValue }) => {
  try {
    const { id, ...restPayload } = payload;

    const response = await Client.patch(
      withTenant(`/leads/${id}`),
      restPayload,
    );

    return {
      message: response?.data?.message || "Lead updated successfully",
      data: response?.data?.data,
    };
  } catch (error: any) {
    return rejectWithValue(
      error?.response?.data?.message || "Failed to update lead",
    );
  }
});

export const deleteLead = createAsyncThunk<
  DeleteLeadResponse,
  string,
  { rejectValue: string }
>("leads/deleteLead", async (id, { rejectWithValue }) => {
  try {
    const response = await Client.delete(withTenant(`/leads/${id}`));

    return {
      message: response?.data?.message || "Lead deleted successfully",
      id,
    };
  } catch (error: any) {
    return rejectWithValue(
      error?.response?.data?.message || "Failed to delete lead",
    );
  }
});

const leadsSlice = createSlice({
  name: "leads",
  initialState,
  reducers: {
    resetLeadsState: (state) => {
      state.createLoading = false;
      state.createError = null;
      state.createSuccess = false;

      state.updateLoading = false;
      state.updateError = null;
      state.updateSuccess = false;

      state.deleteLoading = false;
      state.deleteError = null;
      state.deleteSuccess = false;

      state.detailsLoading = false;
      state.detailsError = null;
    },
    resetLeadsListState: (state) => {
      state.listLoading = false;
      state.listError = null;
      state.leads = [];
      state.total = 0;
      state.page = 1;
      state.limit = 20;
      state.insights = undefined;
    },
    resetLeadDetailsState: (state) => {
      state.leadDetails = null;
      state.detailsLoading = false;
      state.detailsError = null;
    },
  },
  extraReducers: (builder) => {
    builder
      // list
      .addCase(fetchLeads.pending, (state) => {
        state.listLoading = true;
        state.listError = null;
      })
      .addCase(fetchLeads.fulfilled, (state, action) => {
        state.listLoading = false;
        state.leads = action.payload.data;
        state.total = action.payload.total;
        state.page = action.payload.page;
        state.limit = action.payload.limit;
        state.insights = action.payload.insights;
      })
      .addCase(fetchLeads.rejected, (state, action) => {
        state.listLoading = false;
        state.listError = action.payload || "Failed to fetch leads";
      })

      // detail
      .addCase(fetchLeadById.pending, (state) => {
        state.detailsLoading = true;
        state.detailsError = null;
      })
      .addCase(fetchLeadById.fulfilled, (state, action) => {
        state.detailsLoading = false;
        state.leadDetails = action.payload.data;
      })
      .addCase(fetchLeadById.rejected, (state, action) => {
        state.detailsLoading = false;
        state.detailsError = action.payload || "Failed to fetch lead details";
      })

      // create
      .addCase(createLead.pending, (state) => {
        state.createLoading = true;
        state.createError = null;
        state.createSuccess = false;
      })
      .addCase(createLead.fulfilled, (state, action) => {
        state.createLoading = false;
        state.createSuccess = true;
        state.leadDetails = action.payload.data;
      })
      .addCase(createLead.rejected, (state, action) => {
        state.createLoading = false;
        state.createError = action.payload || "Failed to create lead";
        state.createSuccess = false;
      })

      // update
      .addCase(updateLead.pending, (state) => {
        state.updateLoading = true;
        state.updateError = null;
        state.updateSuccess = false;
      })
      .addCase(updateLead.fulfilled, (state, action) => {
        state.updateLoading = false;
        state.updateSuccess = true;
        state.leadDetails = action.payload.data;
        state.leads = state.leads.map((item) =>
          item.id === action.payload.data.id ? action.payload.data : item,
        );
      })
      .addCase(updateLead.rejected, (state, action) => {
        state.updateLoading = false;
        state.updateError = action.payload || "Failed to update lead";
        state.updateSuccess = false;
      })

      // delete
      .addCase(deleteLead.pending, (state) => {
        state.deleteLoading = true;
        state.deleteError = null;
        state.deleteSuccess = false;
      })
      .addCase(deleteLead.fulfilled, (state, action) => {
        state.deleteLoading = false;
        state.deleteSuccess = true;
        state.leads = state.leads.filter(
          (item) => item.id !== action.payload.id,
        );

        if (state.leadDetails?.id === action.payload.id) {
          state.leadDetails = null;
        }
      })
      .addCase(deleteLead.rejected, (state, action) => {
        state.deleteLoading = false;
        state.deleteError = action.payload || "Failed to delete lead";
        state.deleteSuccess = false;
      });
  },
});

export const { resetLeadsState, resetLeadsListState, resetLeadDetailsState } =
  leadsSlice.actions;

// aliases for details page readability
export const fetchLeadDetails = fetchLeadById;
export const clearLeadDetails = resetLeadDetailsState;

export default leadsSlice.reducer;
